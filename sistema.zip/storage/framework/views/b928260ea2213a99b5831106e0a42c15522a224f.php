<label for="nombre">Nombre</label>
<input type="text" name="nombre" value="<?php echo e(isset($empleado->nombre) ? $empleado->nombre : ''); ?>"><br />
<labe for="apellido"l>Apellido</label>
<input type="text" name="apellido" value="<?php echo e(isset($empleado->apellido) ? $empleado->apellido : ''); ?>"><br />
<label for="email">Email</label>
<input type="text" name="email" value="<?php echo e(isset($empleado->email) ? $empleado->email : ''); ?>"><br />
<label for="foto">Foto</label>
<?php if(isset($empleado->foto)): ?>
<img src="<?php echo e(asset('storage').'/'.$empleado->foto); ?>" width="100"/>
<?php endif; ?>
<input type="file" name="foto"><br />
<button type="submit"><?php echo e($modo); ?></button>
<a href="<?php echo e(url('empleado')); ?>">Regresar</a><?php /**PATH H:\res_rs_data\sites\sistema\resources\views/empleado/form.blade.php ENDPATH**/ ?>