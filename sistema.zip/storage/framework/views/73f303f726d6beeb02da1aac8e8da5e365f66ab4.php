

<?php $__env->startSection('content'); ?>
<div class="container">
<?php if(Session::has('mensaje')): ?>
<div class="alert alert-primary" role="alert"><?php echo e(Session::get('mensaje')); ?></div>
<?php endif; ?>
<a href="<?php echo e(url('empleado/create')); ?>">Crear un nuevo empleado</a>
<table class="table">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Foto</th>
            <th>nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($empleado->id); ?></td>
            <td><img src="<?php echo e(asset('storage').'/'.$empleado->foto); ?>" width="100"/></td>
            <td><?php echo e($empleado->nombre); ?></td>
            <td><?php echo e($empleado->apellido); ?></td>
            <td><?php echo e($empleado->email); ?></td>
            <td>
                <a href="<?php echo e(url('/empleado/'.$empleado->id.'/edit')); ?>">
                Editar
                </a>
                /

                <form action="<?php echo e(url('/empleado/'.$empleado->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" onclick="return confirm('quieres borrar?')">Borrar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\res_rs_data\sites\sistema\resources\views/empleado/index.blade.php ENDPATH**/ ?>