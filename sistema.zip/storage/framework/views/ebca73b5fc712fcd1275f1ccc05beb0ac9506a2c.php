

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-primary" role="alert"><?php echo e(Session::get('mensaje')); ?></div>
    <?php endif; ?>
    <a href="<?php echo e(url('empresa/create')); ?>">Crear nueva empresa</a>
    <table class="table">
        <thead class="thead-light">
            <tr>
                <th>#</th>
                <th>Razon Social</th>
                <th>R.I.F.</th>
                <th>Direccion</th>
                <th>Telefono</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($empresa->id); ?></td>
                <td><?php echo e($empresa->razon_social); ?></td>
                <td><?php echo e($empresa->direccion); ?></td>
                <td><?php echo e($empresa->telefono); ?></td>
                <td><?php echo e($empresa->email); ?></td>
                <td>
                    <a href="<?php echo e(url('/empresa/'.$empresa->id.'/edit')); ?>">
                        Editar
                    </a>
                    /

                    <form action="<?php echo e(url('/empresa/'.$empresa->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" onclick="return confirm('quieres borrar?')">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\res_rs_data\sites\sistema\resources\views/empresa/index.blade.php ENDPATH**/ ?>