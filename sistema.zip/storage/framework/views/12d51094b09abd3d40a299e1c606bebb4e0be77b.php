crear empleado
<form action="<?php echo e(url('/empleado')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<label for="nombre">Nombre</label>
<input type="text" name="nombre"><br />
<labe for="apellido"l>Apellido</label>
<input type="text" name="apellido"><br />
<label for="email">Email</label>
<input type="text" name="email"><br />
<label for="foto">Foto</label>
<input type="file" name="foto"><br />
<button type="submit">Enviar</button>
</form><?php /**PATH C:\xampp\htdocs\sistema\resources\views/empleado/create.blade.php ENDPATH**/ ?>