<table class="table">
<thead class="thead-light">
<tr>
<th>#</th>
<th>Foto</th>
<th>nombre</th>
<th>Apellido</th>
<th>Email</th>
<th>Email</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($empleado->id); ?></td>
<td><?php echo e($empleado->foto); ?></td>
<td><?php echo e($empleado->nombre); ?></td>
<td><?php echo e($empleado->apellido); ?></td>
<td><?php echo e($empleado->email); ?></td>
<td>Editar / 

<form action="<?php echo e(url('/empleado/'.$empleado->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo e(method_field('DELETE')); ?>

<button type="submit" onclick="return confirm('quieres borrar?')">Borrar</button>
</form>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table><?php /**PATH C:\xampp\htdocs\sistema\resources\views/empleado/index.blade.php ENDPATH**/ ?>