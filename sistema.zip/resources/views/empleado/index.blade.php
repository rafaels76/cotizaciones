@extends('layouts.app')

@section('content')
<div class="container">
@if(Session::has('mensaje'))
<div class="alert alert-primary" role="alert">{{ Session::get('mensaje') }}</div>
@endif
<a href="{{ url('empleado/create') }}">Crear un nuevo empleado</a>
<table class="table">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>Foto</th>
            <th>nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>
        @foreach($empleados as $empleado)
        <tr>
            <td>{{ $empleado->id }}</td>
            <td><img src="{{ asset('storage').'/'.$empleado->foto }}" width="100"/></td>
            <td>{{ $empleado->nombre }}</td>
            <td>{{ $empleado->apellido }}</td>
            <td>{{ $empleado->email }}</td>
            <td>
                <a href="{{ url('/empleado/'.$empleado->id.'/edit') }}">
                Editar
                </a>
                /

                <form action="{{ url('/empleado/'.$empleado->id) }}" method="post">
                    @csrf
                    {{ method_field('DELETE')}}
                    <button type="submit" onclick="return confirm('quieres borrar?')">Borrar</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
@endsection
